# Supplementary File SF1: Open Targets Conversational Access — Agentic Automation Canvas

This directory contains a complete Agentic Automation Canvas (AAC) example exported as an RO-Crate package, documenting the design of a conversational AI interface for the [Open Targets](https://www.opentargets.org/) drug discovery platform. It serves as Supplementary File SF1 for the AAC manuscript.

## Files

| File | Description |
|------|-------------|
| `ro-crate-metadata.json` | The RO-Crate 1.2 metadata file (JSON-LD) — the FAIR-compliant, machine-readable output |
| `canvas.json` | The source canvas data — can be re-imported into the [AAC web application](https://aac.slolab.ai) for editing |
| `README.md` | This file |

## What This Example Demonstrates

This canvas captures a realistic drug discovery use case: making the Open Targets platform accessible through natural language interfaces powered by agentic AI. It illustrates every dimension of the AAC framework. Person names are deliberately generic role-based placeholders (e.g., "Open Targets Executive", "Platform Engineer", "Industry Drug Discovery Expert") to emphasize that the canvas structure matters more than any specific individual.

### 1. Project Definition
- Clear articulation of the problem (complex database interfaces limit accessibility)
- Quantified headline value (120 researcher-hours/month savings)
- Domain classification and keywords for discoverability
- Version `0.1.0` — this is an initial design-phase canvas, not a post-deployment record

### 2. User Expectations with Benefit Quantification
Four structured requirements with dependencies, demonstrating all five benefit types:

| Requirement | Benefits Demonstrated |
|---|---|
| Natural language querying | **Time** (30→5 min/query with 2 min oversight), **Quality** (40→85% evidence coverage) |
| Evidence summarization | **Time** (60→8 min with 5 min oversight), **Risk** (high→low missing evidence) |
| Mechanism of action exploration | **Enablement** (new capability for non-computational researchers), **Quality** (2→5 graph hops) |
| Report generation | **Time** (4→0.5 hours with 15 min oversight), **Cost** (€400→€80/report) |

Key educational points:
- **Human oversight costs are explicit**: each time benefit includes oversight minutes that reduce net savings
- **Confidence levels differ between users and developers**: users rate time savings as high confidence, but developers rate evidence summarization as low confidence (hallucination risk)
- **Baseline and expected values use different types**: numeric for measurable quantities, categorical for risk levels, binary for enablement
- **Dependencies model workflow**: report generation depends on both querying and summarization

#### Display Groups
Five benefit display groups are pre-configured so the project summary page immediately shows the headline metrics:

| Slot | Benefit Type | Metric | Source Requirement |
|---|---|---|---|
| 1 | Time | Query time | Natural language querying |
| 2 | Time | Synthesis time | Evidence summarization |
| 3 | Quality | Evidence coverage | Natural language querying |
| 4 | Enablement | Non-computational access | MoA exploration |
| 5 | Cost | Report cost | Report generation |

### 3. Developer Feasibility

#### Project-Level Defaults
- **TRL progression**: current 3 (proof of concept) → target 6 (demonstrated in relevant environment)
- **Technology architecture**: RAG with schema-aware GraphQL query generation via custom MCP server
- **Baseline capability analysis**: 55% accuracy without agentic scaffolding → 85-90% expected with it
- **Agentic explanation**: why simple prompting is insufficient (live data access, query planning, access control)
- **Risk assessment**: medium overall, with requirement-specific overrides

#### Task-Level Feasibility Overrides
Each requirement carries its own feasibility assessment, showing how risk and approach vary across tasks:

| Requirement | Risk | Effort | Architecture | Key Challenge |
|---|---|---|---|---|
| NL querying | Medium | 8 weeks | RAG | Ambiguous query disambiguation |
| Evidence summarization | **High** | 6 weeks | Agents (ReAct + MCP) | Hallucination in narrative generation |
| MoA exploration | **High** | 10 weeks | Agents (Plan-and-Execute) | Compounding errors in multi-hop traversal |
| Report generation | Medium | 4 weeks | Agents (ReAct) | Depends on upstream synthesis quality |

This demonstrates the canvas's ability to surface where developer and user confidence diverge: users expect all tasks to work well, but developers flag evidence summarization and MoA exploration as high-risk — surfacing these misalignments early is a core value of the AAC.

### 4. Governance Staging
Three governance phases with explicit decision authority:

| Phase | Duration | Key Agents | Gate Criterion |
|---|---|---|---|
| Prototyping | Jan–Apr 2026 | Platform Engineer, Platform Team | ≥90% benchmark accuracy, zero unauthorized access |
| Internal Testing | May–Aug 2026 | Open Targets Executive, User Panel | ≥80% report time savings, ≥70% adoption intent |
| Public Deployment | Sep–Dec 2026 | Governance Board, Monitoring System | <2% error rate, actual benefits within 20% of predicted |

Note how governance agents evolve: prototyping is developer-led, testing is user-led, deployment involves institutional governance and automated monitoring.

### 5. Data Access and Sensitivity
Four datasets demonstrating the access control challenge:

| Dataset | Access | Sensitivity | Governance Implication |
|---|---|---|---|
| Open Targets Platform | Open | Low | Freely queryable |
| Partner Pre-competitive Data | Restricted | High | MCP server must enforce access control |
| ChEMBL | Open | Low | Supplementary evidence source |
| Europe PMC | Open | Low | Citation retrieval |

The **mixed access levels** are the primary governance challenge: the same user query might require both public and restricted data, and the agentic system must make real-time access control decisions at the MCP server layer. DUO terms (DUO:0000006, DUO:0000012) provide machine-readable data use conditions.

### 6. Outcomes
- **Deliverables**: MCP server, conversational agent, benchmark dataset, evaluation report
- **Evaluations**: Accuracy evaluation and user study with pre-registered metrics
- **Provenance**: each outcome is linked to the governance stage that generated it via `wasGeneratedBy`

## Technical Notes on the RO-Crate

### Ontology Mappings
The `ro-crate-metadata.json` uses six established ontologies plus the AAC custom vocabulary:

| Ontology | Used For | Example |
|---|---|---|
| **Schema.org** | Persons, projects, creative works | `schema:Person`, `schema:Project` |
| **W3C DCAT** | Dataset metadata, access rights | `dcat:Dataset`, `dct:accessRights` |
| **W3C PROV-O** | Governance activities, provenance chains | `prov:Activity`, `wasAssociatedWith` |
| **P-Plan** | Requirements as plan steps with dependencies | `p-plan:Step`, `p-plan:isPreceededBy` |
| **DUO** | Machine-readable data use conditions | `DUO:0000006` (health/medical research) |
| **AAC** | Agentic-specific concepts | `aac:projectStage`, `aac:benefits`, `aac:feasibility` |

### FAIR Compliance
- **Findable**: Schema.org typing enables web search engine discovery; keywords and domain classification support catalog integration
- **Accessible**: Self-contained package with all metadata; persistent identifiers (ORCIDs, DOIs, PIDs) link to external resources
- **Interoperable**: JSON-LD format with standard ontologies; DCAT enables data catalog federation; PROV-O enables provenance tracking
- **Reusable**: CC-BY 4.0 license; DUO terms specify machine-readable use conditions; versioning supports iterative refinement

### Versioning and Living Document
The canvas carries semantic version `0.1.0` with a version date — reflecting that this is an initial design-phase canvas. As the project progresses through governance stages, the canvas would be updated (e.g., to `0.2.0` after prototyping validation, `1.0.0` when entering public deployment with actual evaluation results replacing expected values), creating an auditable trail of how the project design evolved — synchronized with implementation milestones.

## Re-importing This Canvas

To edit this canvas interactively:
1. Visit [https://aac.slolab.ai](https://aac.slolab.ai)
2. Click "Import Canvas"
3. Upload `canvas.json`
4. Edit any section, then export a new RO-Crate

The round-trip import/export ensures that the canvas remains a living document throughout the project lifecycle.
