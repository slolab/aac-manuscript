# Conversational Access to Open Targets Drug Discovery Knowledge

Target version: 0.1.2. Implement to match this specification exactly.

An agentic AI system that makes the Open Targets drug discovery platform accessible through natural language interfaces. Drug discovery experts with biological backgrounds can query drug-target associations, explore evidence across data sources, and generate reports conversationally—rather than through the platform's complex database interfaces.

Objective: Enable drug discovery researchers to access the full breadth of Open Targets evidence through conversational AI, reducing time-to-insight and making the platform accessible to non-computational researchers who currently cannot exploit its full potential.

## Requirements

### Natural language querying of drug-target associations

Users can ask questions like 'What are the top genetic evidence targets for type 2 diabetes?' and receive accurate, sourced answers drawn from the Open Targets Platform data.

- Processing time: 30 → 5 minutes
- Recall: 40 → 85 %
- Tech: architecture: agents | model: Claude 3.5 Sonnet / GPT-4o (frontier-model) | RAG: GraphQL API with schema-aware query generation; text-embedding-3-large; Schema-based: each entity type has dedicated retrieval functions | agentic: framework: ReAct; tools: get_open_targets_graphql_schema, query_open_targets_graphql, batch_query_open_targets_graphql, search_entities; orchestration: local copilot (e.g. Claude or Cursor)

### Cross-source evidence summarization

The system synthesizes evidence from multiple Open Targets data sources into coherent narrative summaries with proper source attribution.

- Processing time: 60 → 8 minutes
- Evidence Synthesis Bias: high → low bias risk
- Tech: architecture: agents | model: Claude 3.5 Sonnet / GPT-4o (frontier-model) | agentic: framework: ReAct, MCP; tools: Open Targets MCP server, evidence_aggregator, citation_tracker; orchestration: LangGraph

### Conversational exploration of drug mechanism of action

Users can engage in multi-turn conversations to explore drug mechanisms of action, traversing the knowledge graph from target to pathway to disease through natural dialogue.

- Satisfaction Score: 2 → 5 out of 5
- New Capability: no → yes graph access
- Tech: architecture: agents | model: Claude 3.5 Sonnet / GPT-4o (frontier-model) | agentic: framework: Plan-and-Execute, MCP; tools: Open Targets MCP server, graph_traversal_planner, conversation_memory; orchestration: LangGraph

### Structured report generation from conversational queries

Users can request structured reports (PDF/Markdown) with citations, figures, and evidence tables suitable for internal target review meetings.

- Processing time: 4 → 0.5 hours
- Operational cost: 400 → 80 EUR
- Tech: architecture: agents | model: Claude 3.5 Sonnet / GPT-4o (frontier-model) | agentic: framework: ReAct; tools: report_template_engine, citation_manager, figure_generator; orchestration: LangGraph

## Data
- Open Targets Platform Data (GraphQL API (JSON responses), open)
- Open Targets Partner Pre-competitive Data (GraphQL API (JSON responses, restricted endpoints), restricted)
- ChEMBL Database (REST API (JSON responses), open)
- Europe PMC Literature Corpus (REST API (XML/JSON responses), open)
- Drug Discovery Query Benchmark Dataset (YAML, open)

## Constraints
- Natural language querying of drug-target associations / Processing time: Baseline assumes researcher moderately familiar with the Open Targets web UI. Expected time includes agent response time plus user verification.
- Natural language querying of drug-target associations / Recall: Manual users typically check only 2-3 evidence types. The agent systematically queries all evidence categories for each target.
- Cross-source evidence summarization / Processing time: Baseline includes navigating each evidence section, interpreting scores, and writing up findings. Low developer confidence reflects challenge of reliable narrative summaries without hallucination.
- Cross-source evidence summarization / Evidence Synthesis Bias: Systematic enumeration of all evidence sources reduces risk of confirmation bias and other biases.
- Conversational exploration of drug mechanism of action / Satisfaction Score: Low developer confidence due to potential for compounding errors in multi-hop reasoning.
- Conversational exploration of drug mechanism of action / New Capability: Currently, exploring multi-hop relationships requires either GraphQL expertise or manual navigation. Conversational access enables medicinal chemists and biologists to perform these explorations directly.
- Structured report generation from conversational queries / Processing time: Baseline includes manual evidence compilation, table creation, narrative writing, and formatting. Higher human oversight because reports go to governance committees.
- Structured report generation from conversational queries / Operational cost: Baseline at ~€100/hour for senior researcher time. Expected cost includes API/compute costs plus reduced researcher time.
